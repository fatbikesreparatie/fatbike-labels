# Fatbike Labels — automatische DHL labels via Shopify webhook

## Omgevingsvariabelen instellen in Render:
- SHOPIFY_SHOP: fatbikesreparatie
- SHOPIFY_TOKEN: (jouw shpat_... token)
- SHOPIFY_SECRET: (jouw webhook secret)
- DHL_USER_ID: 3e375d5f-14ef-48ae-b7af-757426090ca4
- DHL_API_KEY: 4c2a04d3-c336-4b3e-a32e-691bdc79710c
- DHL_ACCOUNT: 06405237
- NOTIFY_EMAIL: info@fatbikesreparatie.nl
